import styled, { css } from 'styled-components';
import { Link } from 'react-router-dom';

// **********************************************************************************
// *** 커스텀 버튼 : <Link> or <button> ***
// **********************************************************************************
// 커스텀 버튼 : <Link> or <button> 디자인 START
const ButtonStyle = css`
    border: none;
    border-radius: 4px;
    font-size: 1rem;
    font-weight: bold;
    padding: 0.25rem 1rem;
    color: white;
    outline: none;
    cursor: pointer;

    background: rgb(115, 171, 255);
    &:hover {
        background: rgb(152, 200, 255);
    }

    ${(props) =>
        props.fullWidth &&
        css`
            padding-top: 0.75rem;
            padding-bottom: 0.75rem;
            width: 100%;
            font-size: 1.125rem;
        `}

    &:disabled {
        background: black;
        color: gray;
        cursor: not-allowed;
    }
`;

const StyledBtn = styled.button`
    ${ButtonStyle}
`;

const StyledBtnLink = styled(Link)`
    ${ButtonStyle}
`;

export const CustomButton = (props) => {
    return props.to ? (
        <StyledBtnLink
            {...props}
            // cyan = {props.cyan ? 1 : 0}
        />
    ) : (
        <StyledBtn {...props} />
    );
};
// 커스텀 버튼 : <Link> or <button> 디자인 END